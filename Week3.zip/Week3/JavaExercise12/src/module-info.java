module JavaExercise12 {
}